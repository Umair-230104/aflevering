package app.routes;

import app.config.HibernateConfig;
import app.controllers.TripController;
import app.daos.GuideDAO;
import app.daos.TripDAO;
import app.dtos.TripDTO;
import app.entities.Category;
import io.javalin.Javalin;
import jakarta.persistence.EntityManagerFactory;
import org.junit.jupiter.api.*;

import java.time.LocalDateTime;
import java.util.List;

import static io.restassured.RestAssured.given;
import static org.hamcrest.MatcherAssert.assertThat;
import static org.hamcrest.Matchers.*;

class TripRoutesTest {

    private static Javalin app;
    private static EntityManagerFactory emf;
    private static String BASE_URL = "http://localhost:7007/api/trips";
    private static TripDAO tripDAO;
    private static GuideDAO guideDAO;
    private static TripController tripController;

    @BeforeAll
    static void init() {
        emf = HibernateConfig.getEntityManagerFactory();
        tripDAO = new TripDAO(emf);
        guideDAO = new GuideDAO(emf);
        tripController = new TripController(tripDAO, guideDAO);

        app = Javalin.create().start(7007);
        app.routes(new Routes().getApiRoutes());
    }

    @BeforeEach
    void setUp() {
        // Populate the database with test data or setup necessary objects for testing
        tripController.populateDatabase(null);
    }

    @AfterEach
    void tearDown() {
        // Clean up database after each test
        if (emf == null) {
            throw new IllegalStateException("EntityManagerFactory is not initialized");
        }

        try (var em = emf.createEntityManager()) {
            em.getTransaction().begin();
            em.createQuery("DELETE FROM Trip").executeUpdate();
            em.createQuery("DELETE FROM Guide").executeUpdate();
            em.createNativeQuery("ALTER SEQUENCE trip_id_seq RESTART WITH 1").executeUpdate();
            em.createNativeQuery("ALTER SEQUENCE guide_id_seq RESTART WITH 1").executeUpdate();
            em.getTransaction().commit();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @AfterAll
    static void closeDown() {
        if (app != null) {
            app.stop();
        }
        if (emf != null) {
            emf.close();
        }
    }

    @Test
    void testGetAllTrips() {
        TripDTO[] trips = given()
                .when()
                .get(BASE_URL)
                .then()
                .statusCode(200)
                .extract().as(TripDTO[].class);

        assertThat(trips.length, is(greaterThan(0))); // Ensure some trips were returned
    }

    @Test
    void testGetTripById() {
        TripDTO trip = given()
                .when()
                .get(BASE_URL + "/1")
                .then()
                .statusCode(200)
                .extract().as(TripDTO.class);

        assertThat(trip.getId(), is(1L));
        assertThat(trip.getName(), notNullValue()); // Assuming name is not null
        assertThat(trip.getPackingItems(), notNullValue()); // Check packing items are included
    }

    @Test
    void testCreateTrip() {
        TripDTO newTrip = new TripDTO(null, "New Trip", 100.0, LocalDateTime.now(), LocalDateTime.now().plusDays(1), "Start Point", null, Category.ADVENTURE);

        TripDTO createdTrip = given()
                .contentType("application/json")
                .body(newTrip)
                .when()
                .post(BASE_URL)
                .then()
                .statusCode(201)
                .extract().as(TripDTO.class);

        assertThat(createdTrip.getId(), notNullValue());
        assertThat(createdTrip.getName(), equalTo("New Trip"));
    }

    @Test
    void testUpdateTrip() {
        TripDTO updatedTrip = new TripDTO(null, "Updated Trip", 150.0, LocalDateTime.now(), LocalDateTime.now().plusDays(2), "Updated Start", null, Category.CULTURAL);

        TripDTO trip = given()
                .contentType("application/json")
                .body(updatedTrip)
                .when()
                .put(BASE_URL + "/1")
                .then()
                .statusCode(200)
                .extract().as(TripDTO.class);

        assertThat(trip.getName(), equalTo("Updated Trip"));
        assertThat(trip.getCategory(), equalTo(Category.CULTURAL));
    }

    @Test
    void testDeleteTrip() {
        given()
                .when()
                .delete(BASE_URL + "/1")
                .then()
                .statusCode(204);

        given()
                .when()
                .get(BASE_URL + "/1")
                .then()
                .statusCode(404); // Trip should no longer exist
    }

    @Test
    void testGetPackingItemsWeight() {
        int totalWeight = given()
                .when()
                .get(BASE_URL + "/1/packingItems/weight")
                .then()
                .statusCode(200)
                .extract().path("totalWeightInGrams");

        assertThat(totalWeight, is(greaterThan(0))); // Check that weight is calculated correctly
    }
}
