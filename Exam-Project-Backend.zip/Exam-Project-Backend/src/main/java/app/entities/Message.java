package app.entities;

public record Message(int status, String message) {}
