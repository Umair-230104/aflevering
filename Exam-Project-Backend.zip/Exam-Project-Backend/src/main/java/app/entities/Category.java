package app.entities;

public enum Category {
    ADVENTURE,
    LEISURE,
    HISTORICAL,
    CULTURAL,
    WILDLIFE
}
