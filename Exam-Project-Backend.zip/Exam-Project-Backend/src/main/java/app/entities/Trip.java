package app.entities;


import app.dtos.TripDTO;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Entity
@NoArgsConstructor
@AllArgsConstructor
@Getter

public class Trip
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    private String name;
    private double price;
    private LocalDateTime startTime;
    private LocalDateTime endTime;
    private String startPosition;

    @ManyToOne
    @Setter
    private Guide guide;

    @Enumerated(EnumType.STRING)
    private Category category;

    public Trip(TripDTO tripDTO)
    {
        this.name = tripDTO.getName();
        this.price = tripDTO.getPrice();
        this.startTime = tripDTO.getStartTime();
        this.endTime = tripDTO.getEndTime();
        this.startPosition = tripDTO.getStartPosition();
        this.category = tripDTO.getCategory();
    }

    public void updateToTripDTO(TripDTO tripDTO)
    {
        this.name = tripDTO.getName();
        this.price = tripDTO.getPrice();
        this.startTime = tripDTO.getStartTime();
        this.endTime = tripDTO.getEndTime();
        this.startPosition = tripDTO.getStartPosition();
        this.category = tripDTO.getCategory();
    }

}
