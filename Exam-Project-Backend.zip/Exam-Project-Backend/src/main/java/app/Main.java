package app;

import app.config.AppConfig;

public class Main
{
    public static void main(String[] args)
    {
        AppConfig.startServer();
    }
}
