package app.config;

import app.daos.GuideDAO;
import app.daos.TripDAO;
import app.dtos.GuideDTO;
import app.dtos.TripDTO;
import app.entities.Category;

import java.time.LocalDateTime;
import java.util.ArrayList;

public class Populator {

    private final TripDAO tripDAO;
    private final GuideDAO guideDAO;

    public Populator(TripDAO tripDAO, GuideDAO guideDAO) {
        this.tripDAO = tripDAO;
        this.guideDAO = guideDAO;
    }

    public void populateDatabase() {
        // Create and persist guides
        GuideDTO guide1 = new GuideDTO(null, "John", "Doe", "john@example.com", 12345678, 10, new ArrayList<>());
        GuideDTO guide2 = new GuideDTO(null, "Jane", "Smith", "jane@example.com", 87654321, 5, new ArrayList<>());

        guide1 = guideDAO.create(guide1); // Now guide1 has a persisted ID
        guide2 = guideDAO.create(guide2); // Now guide2 has a persisted ID

        // Use persisted GuideDTOs to create trips with correct guide references
        TripDTO trip1 = new TripDTO(null, "Mountain Adventure", 299.99, LocalDateTime.now().plusDays(1), LocalDateTime.now().plusDays(5), "Base Camp", guide1.getId(), Category.ADVENTURE);
        TripDTO trip2 = new TripDTO(null, "Historical City Tour", 150.00, LocalDateTime.now().plusDays(3), LocalDateTime.now().plusDays(4), "Old Town", guide2.getId(), Category.HISTORICAL);
        TripDTO trip3 = new TripDTO(null, "Wildlife Safari", 400.00, LocalDateTime.now().plusDays(7), LocalDateTime.now().plusDays(10), "National Park", guide1.getId(), Category.WILDLIFE);



        // Persist trips
        tripDAO.create(trip1);
        tripDAO.create(trip2);
        tripDAO.create(trip3);

        System.out.println("Database populated with sample trips and guides.");
    }
}
