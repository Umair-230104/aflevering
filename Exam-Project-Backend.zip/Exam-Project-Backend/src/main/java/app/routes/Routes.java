package app.routes;

import io.javalin.apibuilder.EndpointGroup;

import static io.javalin.apibuilder.ApiBuilder.path;

public class Routes
{
    TripRoutes tripRoutes = new TripRoutes();

    public EndpointGroup getApiRoutes()
    {
        return () ->
        {
            path("/trip", tripRoutes.getDoctorRoutes());
        };
    }
}
