package app.routes;

import app.config.HibernateConfig;
import app.controllers.TripController;
import app.daos.GuideDAO;
import app.daos.TripDAO;
import io.javalin.apibuilder.EndpointGroup;
import jakarta.persistence.EntityManagerFactory;

import static io.javalin.apibuilder.ApiBuilder.*;

public class TripRoutes
{
    private final EntityManagerFactory emf = HibernateConfig.getEntityManagerFactory();
    TripDAO tripDAO = new TripDAO(emf);
    GuideDAO guideDAO = new GuideDAO(emf);
    TripController tripController = new TripController(tripDAO, guideDAO);

    public EndpointGroup getDoctorRoutes()
    {
        return () ->
        {
            get("/", tripController::getAll);
            get("/{id}", tripController::getById);
            post("/", tripController::createTrip);
            put("/{id}", tripController::updateTrip);
            delete("/{id}", tripController::deleteTrip);
            put("/trips/{tripId}/guides/{guideId}", tripController::addGuideToTrip);
            post("/trips/populate", tripController::populateDatabase);

            get("/category/{category}", tripController::getTripsByCategory);
            get("/guides/summaries", tripController::getGuideSummaries);

            get("/{id}/packingItems/weight", tripController::getPackingItemsWeight);


        };
    }
}
