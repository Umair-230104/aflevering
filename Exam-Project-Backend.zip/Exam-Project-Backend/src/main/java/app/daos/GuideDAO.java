package app.daos;

import app.dtos.GuideDTO;
import app.dtos.GuideSummaryDTO;
import app.entities.Guide;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;

import java.util.List;

public class GuideDAO implements IDAO<GuideDTO>
{
    private final EntityManagerFactory emf;

    public GuideDAO(EntityManagerFactory emf)
    {
        this.emf = emf;
    }

    @Override
    public GuideDTO create(GuideDTO guideDTO)
    {
        Guide guide = new Guide(guideDTO);
        try (EntityManager em = emf.createEntityManager())
        {
            em.getTransaction().begin();
            em.persist(guide);
            em.getTransaction().commit();
            return new GuideDTO(guide);
        }
    }

    @Override
    public List<GuideDTO> getAll()
    {
        return List.of();
    }

    @Override
    public GuideDTO getById(Integer id)
    {
        return null;
    }

    @Override
    public GuideDTO update(int id, GuideDTO guideDTO)
    {
        try (EntityManager em = emf.createEntityManager())
        {
            em.getTransaction().begin();

            Guide updatedGuide = em.find(Guide.class, guideDTO.getId());
            if (updatedGuide != null)
            {
                updatedGuide.updateToGuideDTO(guideDTO);
            }
            em.getTransaction().commit();
            return new GuideDTO(updatedGuide);
        }
    }

    @Override
    public void delete(Integer id)
    {
        try (EntityManager em = emf.createEntityManager())
        {
            em.getTransaction().begin();
            Guide guide = em.find(Guide.class, id);
            if (guide != null)
            {
                em.remove(guide);
                em.getTransaction().commit();
            } else
            {
                em.getTransaction().rollback();
            }
        }
    }

    public List<GuideSummaryDTO> getGuideSummaries() {
        try (EntityManager em = emf.createEntityManager()) {
            String query = "SELECT new app.dtos.GuideSummaryDTO(g.id, g.firstName, g.lastName, SUM(t.price)) " +
                    "FROM Guide g JOIN g.trips t GROUP BY g.id";

            return em.createQuery(query, GuideSummaryDTO.class).getResultList();
        }
    }
}
