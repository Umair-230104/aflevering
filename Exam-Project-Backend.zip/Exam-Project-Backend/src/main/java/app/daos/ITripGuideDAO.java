package app.daos;

import app.dtos.TripDTO;

import java.util.Set;

public interface ITripGuideDAO
{
    TripDTO addGuideToTrip(int tripId, int guideId);
    Set<TripDTO> getTripsByGuide(int guideId);
}
