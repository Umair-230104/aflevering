package app.daos;

import app.dtos.GuideSummaryDTO;
import app.dtos.TripDTO;
import app.entities.Category;
import app.entities.Guide;
import app.entities.Trip;
import app.exceptions.ApiException;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

public class TripDAO implements IDAO<TripDTO>, ITripGuideDAO
{
    private final EntityManagerFactory emf;

    public TripDAO(EntityManagerFactory emf)
    {
        this.emf = emf;
    }

    @Override
    public TripDTO create(TripDTO tripDTO)
    {
        Trip trip = new Trip(tripDTO);
        try (EntityManager em = emf.createEntityManager())
        {
            em.getTransaction().begin();
            if (tripDTO.getGuideId() != null)
            {
                Guide guide = em.find(Guide.class, tripDTO.getGuideId());
                trip.setGuide(guide);
            }
            em.persist(trip);
            em.getTransaction().commit();
            return new TripDTO(trip);
        }
    }

    @Override
    public List<TripDTO> getAll()
    {
        try (EntityManager em = emf.createEntityManager())
        {
            List<Trip> trips = em.createQuery("SELECT t FROM Trip t", Trip.class).getResultList();
            return trips.stream().map(TripDTO::new).toList();
        }
    }

    @Override
    public TripDTO getById(Integer id) {
        try (EntityManager em = emf.createEntityManager()) {
            Trip trip = em.find(Trip.class, id);
            return trip != null ? new TripDTO(trip, trip.getGuide()) : null;
        }
    }

    @Override
    public TripDTO update(int id, TripDTO tripDTO)
    {
        try (EntityManager em = emf.createEntityManager())
        {
            em.getTransaction().begin();

            Trip updatedTrip = em.find(Trip.class, id);
            if (updatedTrip != null)
            {
                updatedTrip.updateToTripDTO(tripDTO);
            }
            em.getTransaction().commit();
            return updatedTrip != null ? new TripDTO(updatedTrip) : null;
        }
    }

    @Override
    public void delete(Integer id) {
        try (EntityManager em = emf.createEntityManager()) {
            em.getTransaction().begin();
            Trip trip = em.find(Trip.class, id);
            if (trip == null) {
                em.getTransaction().rollback();
                throw new ApiException(404, "Trip with ID " + id + " not found"); // Throw if not found
            }
            em.remove(trip);
            em.getTransaction().commit();
        }
    }

    @Override
    public TripDTO addGuideToTrip(int tripId, int guideId)
    {
        try (EntityManager em = emf.createEntityManager())
        {
            em.getTransaction().begin();
            Guide guide = em.find(Guide.class, guideId);
            Trip trip = em.find(Trip.class, tripId);

            if (guide != null && trip != null)
            {
                guide.getTrips().add(trip);
                trip.setGuide(guide);
                em.getTransaction().commit();
                return new TripDTO(trip);
            } else
            {
                em.getTransaction().rollback();
                return null;
            }
        }
    }

    @Override
    public Set<TripDTO> getTripsByGuide(int guideId)
    {
        try (EntityManager em = emf.createEntityManager())
        {
            Guide guide = em.find(Guide.class, guideId);
            return guide != null ? guide.getTrips().stream().map(TripDTO::new).collect(Collectors.toSet()) : null;
        }
    }

    public List<TripDTO> getTripsByCategory(Category category) {
        try (EntityManager em = emf.createEntityManager()) {
            List<Trip> trips = em.createQuery("SELECT t FROM Trip t WHERE t.category = :category", Trip.class)
                    .setParameter("category", category)
                    .getResultList();
            return trips.stream().map(TripDTO::new).collect(Collectors.toList());
        }
    }




}
