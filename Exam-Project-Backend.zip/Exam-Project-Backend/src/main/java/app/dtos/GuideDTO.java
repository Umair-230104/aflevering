package app.dtos;

import app.entities.Guide;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.List;

@NoArgsConstructor
@AllArgsConstructor
@Getter
public class GuideDTO
{
    private Long id;
    private String firstName;
    private String lastName;
    private String email;
    private int phone;
    private int yearsOfExperience;
    private List<TripDTO> tripDTOS;

public GuideDTO(Guide guide) {
    this.id = guide.getId();
    this.firstName = guide.getFirstName();
    this.lastName = guide.getLastName();
    this.email = guide.getEmail();
    this.phone = guide.getPhone();
    this.yearsOfExperience = guide.getYearsOfExperience();
    this.tripDTOS = guide.getTrips() != null ? TripDTO.listToDTO(guide.getTrips()) : new ArrayList<>();
}
}
