package app.dtos;

import lombok.AllArgsConstructor;
import lombok.Getter;

@AllArgsConstructor
@Getter
public class GuideSummaryDTO {
    private Long id;
    private String firstName;
    private String lastName;
    private Double totalTripPrice;
}
