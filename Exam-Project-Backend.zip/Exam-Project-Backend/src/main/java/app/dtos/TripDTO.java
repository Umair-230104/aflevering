package app.dtos;


import app.entities.Category;
import app.entities.Guide;
import app.entities.Trip;
import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Setter;

@NoArgsConstructor
@AllArgsConstructor
@Getter
@JsonInclude(JsonInclude.Include.NON_NULL) // Only include non-null fields in JSON
public class TripDTO {
    private Long id;
    @Setter
    private String name;
    private double price;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS")
    private LocalDateTime startTime;

    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSS")
    private LocalDateTime endTime;

    private String startPosition;
    private Long guideId; // Set this only when GuideDTO is null
    private GuideDTO guide; // Set this only for full GuideDTO response
    private Category category;
    @Setter
    private List<PackingItemDTO> packingItems; // New field for packing items


    public TripDTO(Trip trip) {
        this.id = trip.getId();
        this.name = trip.getName();
        this.price = trip.getPrice();
        this.startTime = trip.getStartTime();
        this.endTime = trip.getEndTime();
        this.startPosition = trip.getStartPosition();
        this.category = trip.getCategory();


        // Only set guideId if guide is not included
        this.guideId = (trip.getGuide() != null) ? trip.getGuide().getId() : null;
    }

    // Secondary constructor for getById response with full GuideDTO
    public TripDTO(Trip trip, Guide guide) {
        this(trip); // Initialize common fields
        this.guide = (guide != null) ? new GuideDTO(guide) : null; // Full GuideDTO when guide is provided
        this.guideId = null; // Remove guideId when GuideDTO is populated
    }

    public TripDTO(Long id, String name, double price, LocalDateTime startTime, LocalDateTime endTime, String startPosition, Long guideId, Category category)
    {
        this.id = id;
        this.name = name;
        this.price = price;
        this.startTime = startTime;
        this.endTime = endTime;
        this.startPosition = startPosition;
        this.guideId = guideId;
        this.category = category;
    }

    public static List<TripDTO> listToDTO(List<Trip> trips) {
        return trips.stream().map(TripDTO::new).collect(Collectors.toList());
    }
}
