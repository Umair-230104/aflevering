package app.controllers;

import app.config.Populator;
import app.daos.GuideDAO;
import app.daos.TripDAO;
import app.dtos.GuideSummaryDTO;
import app.dtos.PackingItemDTO;
import app.dtos.TripDTO;
import app.entities.Category;
import app.exceptions.ApiException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.javalin.http.Context;


import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.net.URI;

import java.util.List;
import java.util.Map;

public class TripController
{

    private final TripDAO tripDAO;
    private final GuideDAO guideDAO;
    private final ObjectMapper objectMapper = new ObjectMapper()
            .registerModule(new com.fasterxml.jackson.datatype.jsr310.JavaTimeModule())
            .disable(com.fasterxml.jackson.databind.SerializationFeature.WRITE_DATES_AS_TIMESTAMPS);


    private final Populator populator;

    public TripController(TripDAO tripDAO, GuideDAO guideDAO)
    {
        this.tripDAO = tripDAO;
        this.guideDAO = guideDAO;
        this.populator = new Populator(tripDAO, guideDAO);
    }

    //Method to Create a new trip
    public void createTrip(Context ctx)
    {
        TripDTO tripDTO = ctx.bodyAsClass(TripDTO.class);
        TripDTO newTrip = tripDAO.create(tripDTO);
        ctx.res().setStatus(201);
        ctx.json(newTrip, TripDTO.class);
    }

    public void getAll(Context ctx)
    {
        List<TripDTO> trips = tripDAO.getAll();
        ctx.res().setStatus(200);
        ctx.json(trips, TripDTO.class);
    }

//    public void getById(Context ctx) {
//        try {
//            int id = Integer.parseInt(ctx.pathParam("id"));
//            TripDTO trip = tripDAO.getById(id);
//            ctx.status(200).json(trip);
//        } catch (Exception e) {
//            throw new ApiException(404, "Trip with ID " + ctx.pathParam("id") + " not found");
//        }
//    }

    public void getById(Context ctx) {
        int id = Integer.parseInt(ctx.pathParam("id"));
        TripDTO trip = tripDAO.getById(id);

        if (trip != null) {
            try {
                List<PackingItemDTO> packingItems = fetchPackingItemsByCategory(trip.getCategory().name().toLowerCase());
                trip.setPackingItems(packingItems); // Set packing items in TripDTO

                ctx.json(trip);
            } catch (Exception e) {
                ctx.status(500).result("Error fetching packing items: " + e.getMessage());
            }
        } else {
            ctx.status(404).result("Trip not found");
        }
    }


    public void updateTrip(Context ctx)
    {
        int id = Integer.parseInt(ctx.pathParam("id"));
        TripDTO tripDTO = ctx.bodyAsClass(TripDTO.class);
        TripDTO updatedTrip = tripDAO.update(id, tripDTO);
        ctx.res().setStatus(200);
        ctx.json(updatedTrip, TripDTO.class);
    }

    public void deleteTrip(Context ctx) {
        int id = Integer.parseInt(ctx.pathParam("id"));
        tripDAO.delete(id); // Will throw ApiException if the trip is not found
        ctx.status(204); // Reached only if deletion was successful
    }

    public void addGuideToTrip(Context ctx)
    {
        int tripId = Integer.parseInt(ctx.pathParam("tripId"));
        int guideId = Integer.parseInt(ctx.pathParam("guideId"));
        TripDTO trip = tripDAO.addGuideToTrip(tripId, guideId);
        ctx.res().setStatus(200);
        ctx.json(trip, TripDTO.class);
    }

    public void populateDatabase(Context ctx) {
        populator.populateDatabase();
        ctx.res().setStatus(200);
        ctx.result("Database populated with sample trips and guides.");
    }

    public void getTripsByCategory(Context ctx) {
        String categoryParam = ctx.pathParam("category");
        Category category = Category.valueOf(categoryParam.toUpperCase()); // Assuming Category is an enum
        List<TripDTO> trips = tripDAO.getTripsByCategory(category);
        ctx.res().setStatus(200);
        ctx.json(trips);
    }

    public void getGuideSummaries(Context ctx) {
        List<GuideSummaryDTO> summaries = guideDAO.getGuideSummaries();
        ctx.json(summaries);
    }

    private String mapToSupportedCategory(String category) {
        return switch (category.toLowerCase()) {
            case "adventure" -> "forest";       // Maps ADVENTURE to "forest"
            case "leisure" -> "beach";          // Maps LEISURE to "beach"
            case "historical" -> "city";        // Maps HISTORICAL to "city"
            case "cultural" -> "city";          // Maps CULTURAL to "city"
            case "wildlife" -> "forest";        // Maps WILDLIFE to "forest"
            default -> category;                // Hvis den allerede er understøttet, brug den som den er
        };
    }


    public List<PackingItemDTO> fetchPackingItemsByCategory(String category) throws Exception {
    String mappedCategory = mapToSupportedCategory(category); // Brug den nye metode
    String apiUrl = "https://packingapi.cphbusinessapps.dk/packinglist/" + mappedCategory;

    HttpClient client = HttpClient.newHttpClient();
    HttpRequest request = HttpRequest.newBuilder()
            .uri(new URI(apiUrl))
            .GET()
            .build();

    HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());

    if (response.statusCode() == 200) {
        // Antag at API’et returnerer et objekt med en nøgle "items" som indeholder pakkelisten
        Map<String, List<PackingItemDTO>> responseMap = objectMapper.readValue(response.body(), new TypeReference<>() {});
        return responseMap.get("items");
    } else {
        throw new RuntimeException("Kunne ikke hente pakkelisten. Statuskode: " + response.statusCode());
    }
}



    public void getPackingItemsWeight(Context ctx) {
        int id = Integer.parseInt(ctx.pathParam("id"));
        TripDTO trip = tripDAO.getById(id);

        if (trip != null) {
            try {
                List<PackingItemDTO> packingItems = fetchPackingItemsByCategory(trip.getCategory().name().toLowerCase());
                int totalWeight = packingItems.stream().mapToInt(item -> item.getWeightInGrams() * item.getQuantity()).sum();

                ctx.json(Map.of("totalWeightInGrams", totalWeight));
            } catch (Exception e) {
                ctx.status(500).result("Error calculating total weight: " + e.getMessage());
            }
        } else {
            ctx.status(404).result("Trip not found");
        }
    }
}
