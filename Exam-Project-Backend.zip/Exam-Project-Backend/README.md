POST http://localhost:7007/api/trip/trips/populate

HTTP/1.1 200 OK
Date: Mon, 04 Nov 2024 11:10:24 GMT
Content-Type: text/plain
Content-Length: 48

Database populated with sample trips and guides.

Response code: 200 (OK); Time: 224ms (224 ms); Content length: 48 bytes (48 B)


GET http://localhost:7007/api/trip

HTTP/1.1 200 OK
Date: Mon, 04 Nov 2024 11:10:32 GMT
Content-Type: application/json
Content-Length: 568

[
{
"id": 1,
"name": "Mountain Adventure",
"price": 299.99,
"startTime": "2024-11-05T12:10:25.064",
"endTime": "2024-11-09T12:10:25.064",
"startPosition": "Base Camp",
"guideId": 1,
"category": "ADVENTURE"
},
{
"id": 2,
"name": "Historical City Tour",
"price": 150.0,
"startTime": "2024-11-07T12:10:25.064",
"endTime": "2024-11-08T12:10:25.064",
"startPosition": "Old Town",
"guideId": 2,
"category": "HISTORICAL"
},
{
"id": 3,
"name": "Wildlife Safari",
"price": 400.0,
"startTime": "2024-11-11T12:10:25.064",
"endTime": "2024-11-14T12:10:25.064",
"startPosition": "National Park",
"guideId": 1,
"category": "WILDLIFE"
}
]
Response file saved.
> 2024-11-04T121032.200.json

Response code: 200 (OK); Time: 276ms (276 ms); Content length: 568 bytes (568 B)


GET http://localhost:7007/api/trip/2

HTTP/1.1 200 OK
Date: Mon, 04 Nov 2024 11:11:45 GMT
Content-Type: application/json
Content-Length: 529

{
"id": 2,
"name": "UPDATED TRIP: Desert Exploration",
"price": 200.0,
"startTime": "2024-11-15T08:00:00.000",
"endTime": "2024-11-17T18:00:00.000",
"startPosition": "Desert Base",
"guide": {
"id": 2,
"firstName": "Jane",
"lastName": "Smith",
"email": "jane@example.com",
"phone": 87654321,
"yearsOfExperience": 5,
"tripDTOS": [
{
"id": 2,
"name": "UPDATED TRIP: Desert Exploration",
"price": 200.0,
"startTime": "2024-11-15T08:00:00.000",
"endTime": "2024-11-17T18:00:00.000",
"startPosition": "Desert Base",
"guideId": 2,
"category": "ADVENTURE"
}
]
},
"category": "ADVENTURE"
}
Response file saved.
> 2024-11-04T121145.200.json

Response code: 200 (OK); Time: 19ms (19 ms); Content length: 529 bytes (529 B)



POST http://localhost:7007/api/trip

HTTP/1.1 201 Created
Date: Mon, 04 Nov 2024 11:10:38 GMT
Content-Type: application/json
Content-Length: 177

{
"id": 4,
"name": "Desert Exploration",
"price": 200.0,
"startTime": "2024-11-15T08:00:00.000",
"endTime": "2024-11-17T18:00:00.000",
"startPosition": "Desert Base",
"category": "ADVENTURE"
}
Response file saved.
> 2024-11-04T121038.201.json

Response code: 201 (Created); Time: 44ms (44 ms); Content length: 177 bytes (177 B)


PUT http://localhost:7007/api/trip/2

HTTP/1.1 200 OK
Date: Mon, 04 Nov 2024 11:10:45 GMT
Content-Type: application/json
Content-Length: 203

{
"id": 2,
"name": "UPDATED TRIP: Desert Exploration",
"price": 200.0,
"startTime": "2024-11-15T08:00:00.000",
"endTime": "2024-11-17T18:00:00.000",
"startPosition": "Desert Base",
"guideId": 2,
"category": "ADVENTURE"
}
Response file saved.
> 2024-11-04T121045.200.json

Response code: 200 (OK); Time: 26ms (26 ms); Content length: 203 bytes (203 B)


DELETE http://localhost:7007/api/trip/1

HTTP/1.1 204 No Content
Date: Mon, 04 Nov 2024 11:10:52 GMT
Content-Type: text/plain

<Response body is empty>

Response code: 204 (No Content); Time: 22ms (22 ms); Content length: 0 bytes (0 B)


PUT http://localhost:7007/api/trip/trips/4/guides/1

HTTP/1.1 200 OK
Date: Mon, 04 Nov 2024 11:10:57 GMT
Content-Type: application/json
Content-Length: 189

{
"id": 4,
"name": "Desert Exploration",
"price": 200.0,
"startTime": "2024-11-15T08:00:00.000",
"endTime": "2024-11-17T18:00:00.000",
"startPosition": "Desert Base",
"guideId": 1,
"category": "ADVENTURE"
}
Response file saved.
> 2024-11-04T121057.200.json

Response code: 200 (OK); Time: 24ms (24 ms); Content length: 189 bytes (189 B)


